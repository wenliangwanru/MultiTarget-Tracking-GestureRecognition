from pylab import *
from tkinter import *
import numpy as np
import scipy.io as scio
import Play_mp3
import time
np.set_printoptions(suppress = True)


file_name="01030504"
total_step=500
#########################
class Application():
    def __init__(self):
        super(Application,self).__init__()   
        self.total_step= total_step        
        self.SNTs=np.ones((1, 2)) 
        Play_mp3.play('ready.wav')
        self.now1=time.time()
        self.SNTs[ 0, 0]= 0
        self.SNTs[ 0, 1]='{:.10f}'.format(self.now1)    
        self.save_path="\\"+file_name+"_SNTs.mat"  ###set the path
        scio.savemat(self.save_path, { "SNTs" :  self.SNTs} )
        
        for step in range(1,self.total_step+1):

            time.sleep(0.8)
            Play_mp3.play('go.wav') 
            self.now2=time.time() 
            print(step)
            
            self.SNT=np.ones((1, 2 ))
            self.SNT[ 0, 0]= int(step)
            self.SNT[ 0, 1]='{:.10f}'.format(self.now2)              
            self.SNTs=np.concatenate(( self.SNTs,  self.SNT ),axis=0)   
            
            self.save_path="\\"+file_name+"_SNTs.mat" ###set the path
            scio.savemat(self.save_path, { "SNTs" :  self.SNTs} )
        
        Play_mp3.play('end.wav') 
        self.now3=time.time()
        self.SNT[ 0, 0]= -1
        self.SNT[ 0, 1]='{:.10f}'.format(self.now3) 
        self.SNTs=np.concatenate(( self.SNTs, self.SNT ),axis=0)   
        self.save_path="\\"+file_name+"_SNTs.mat" ###set the path
        scio.savemat(self.save_path, { "SNTs" :  self.SNTs} )
##########################################
if __name__ == '__main__':

     app = Application()
     
######## SNTs[-1,1]- SNTs[0,1]

